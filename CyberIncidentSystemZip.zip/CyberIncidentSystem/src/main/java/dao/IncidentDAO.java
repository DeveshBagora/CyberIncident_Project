package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.Incident;
import util.DBConnection;

public class IncidentDAO {

    // ===============================
    // ADD INCIDENT
    // ===============================
    public boolean addIncident(Incident incident) {
        boolean status = false;

        try (Connection con = DBConnection.getConnection()) {

            String sql = "INSERT INTO incidents (user_id, title, description, type, status, priority, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, incident.getUserId());
            ps.setString(2, incident.getTitle());
            ps.setString(3, incident.getDescription());
            ps.setString(4, incident.getType());
            ps.setString(5, incident.getStatus());
            ps.setString(6, incident.getPriority());
            ps.setTimestamp(7, new Timestamp(System.currentTimeMillis()));

            status = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }


    // ===============================
    // GET ALL INCIDENTS
    // ===============================
    public List<Incident> getAllIncidents() {

        List<Incident> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT * FROM incidents";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Incident i = new Incident();

                i.setIncidentId(rs.getInt("incident_id"));
                i.setUserId(rs.getInt("user_id"));
                i.setTitle(rs.getString("title"));
                i.setDescription(rs.getString("description"));
                i.setType(rs.getString("type"));
                i.setStatus(rs.getString("status"));
                i.setPriority(rs.getString("priority"));
                i.setCreatedAt(rs.getTimestamp("created_at"));

                list.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    // ===============================
    // GET INCIDENTS BY USER
    // ===============================
    public List<Incident> getIncidentsByUser(int userId) {

        List<Incident> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT * FROM incidents WHERE user_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, userId);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Incident i = new Incident();

                i.setIncidentId(rs.getInt("incident_id"));
                i.setUserId(rs.getInt("user_id"));
                i.setTitle(rs.getString("title"));
                i.setDescription(rs.getString("description"));
                i.setType(rs.getString("type"));
                i.setStatus(rs.getString("status"));
                i.setPriority(rs.getString("priority"));
                i.setCreatedAt(rs.getTimestamp("created_at"));

                list.add(i);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }


    // ===============================
    // UPDATE STATUS
    // ===============================
    public boolean updateStatus(int id, String status) {
        boolean result = false;

        try (Connection con = DBConnection.getConnection()) {

            String sql = "UPDATE incidents SET status=? WHERE incident_id=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, status);
            ps.setInt(2, id);

            result = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }


    // ===============================
    // DELETE INCIDENT
    // ===============================
    public boolean deleteIncident(int incidentId) {

        boolean result = false;

        try (Connection con = DBConnection.getConnection()) {

            String sql = "DELETE FROM incidents WHERE incident_id=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, incidentId);

            result = ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }


    // ===============================
    // TOTAL INCIDENTS
    // ===============================
    public int getTotalIncidents() {

        int count = 0;

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT COUNT(*) FROM incidents";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }


    // ===============================
    // COUNT BY STATUS
    // ===============================
    public int countByStatus(String status) {

        int count = 0;

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT COUNT(*) FROM incidents WHERE status=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, status);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }


    // ===============================
    // COUNT BY PRIORITY
    // ===============================
    public int countByPriority(String priority) {

        int count = 0;

        try (Connection con = DBConnection.getConnection()) {

            String sql = "SELECT COUNT(*) FROM incidents WHERE priority=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, priority);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }
}