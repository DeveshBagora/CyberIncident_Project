package Controller;

import java.io.IOException;
import java.util.List;

import dao.IncidentDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import model.Incident;

@WebServlet("/AdminViewIncidentsServlet")
public class AdminViewIncidentsServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        IncidentDAO dao = new IncidentDAO();
        List<Incident> list = dao.getAllIncidents();

        // Debug
        System.out.println("Total Incidents: " + list.size());

        request.setAttribute("incidents", list);

        request.getRequestDispatcher("/jsp/adminIncidents.jsp")
               .forward(request, response);
    }
}