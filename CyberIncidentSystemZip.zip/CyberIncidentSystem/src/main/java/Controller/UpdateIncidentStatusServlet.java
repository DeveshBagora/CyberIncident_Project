package Controller;

import dao.IncidentDAO;
import dao.UserDAO;
import model.User;
import util.EmailUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/UpdateIncidentStatusServlet")
public class UpdateIncidentStatusServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            int incidentId = Integer.parseInt(request.getParameter("incidentId"));
            String newStatus = request.getParameter("status");
            int userId = Integer.parseInt(request.getParameter("userId"));

            IncidentDAO incidentDAO = new IncidentDAO();
            UserDAO userDAO = new UserDAO();

            boolean updated = incidentDAO.updateStatus(incidentId, newStatus);

            if(updated){

                User user = userDAO.getUserById(userId);

                if(user != null){

                    EmailUtil.sendEmail(
                        user.getEmail(),
                        "Incident Status Updated",
                        "Dear User,\n\n" +
                        "Your incident status has been updated.\n\n" +
                        "New Status: " + newStatus + "\n\n" +
                        "Regards,\nCyber Incident System"
                    );
                }

                response.sendRedirect("AdminViewIncidentsServlet");

            } else {
                response.getWriter().println("Status update failed");
            }

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}