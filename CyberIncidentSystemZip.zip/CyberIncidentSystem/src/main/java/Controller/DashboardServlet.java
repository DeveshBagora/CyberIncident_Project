package Controller;

import java.io.IOException;

import dao.IncidentDAO;
import dao.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/DashboardServlet")
public class DashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        IncidentDAO incidentDAO = new IncidentDAO();
        UserDAO userDAO = new UserDAO();

        // Fetch data
        int totalUsers = userDAO.getTotalUsers();
        int totalIncidents = incidentDAO.getTotalIncidents();
        int resolved = incidentDAO.countByStatus("Resolved");
        int pending = incidentDAO.countByStatus("Pending");
        int inProgress = incidentDAO.countByStatus("In Progress");

        int low = incidentDAO.countByPriority("Low");
        int medium = incidentDAO.countByPriority("Medium");
        int high = incidentDAO.countByPriority("High");

        // Set attributes
        request.setAttribute("totalUsers", totalUsers);
        request.setAttribute("totalIncidents", totalIncidents);
        request.setAttribute("resolved", resolved);
        request.setAttribute("pending", pending);
        request.setAttribute("inProgress", inProgress);

        request.setAttribute("low", low);
        request.setAttribute("medium", medium);
        request.setAttribute("high", high);

        // Forward to JSP
        request.getRequestDispatcher("/jsp/dashboard.jsp")
               .forward(request, response);
    }
}