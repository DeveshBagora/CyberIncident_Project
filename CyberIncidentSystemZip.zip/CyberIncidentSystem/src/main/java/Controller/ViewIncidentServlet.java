package Controller;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import dao.IncidentDAO;
import model.Incident;
import model.User;

@WebServlet("/ViewIncidentServlet")
public class ViewIncidentServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("jsp/login.jsp");
            return;
        }

        IncidentDAO dao = new IncidentDAO();
        List<Incident> incidents = dao.getIncidentsByUser(user.getUserId());

        request.setAttribute("incidents", incidents);
        RequestDispatcher rd = request.getRequestDispatcher("jsp/viewincidents.jsp");
        rd.forward(request, response);
    }
}