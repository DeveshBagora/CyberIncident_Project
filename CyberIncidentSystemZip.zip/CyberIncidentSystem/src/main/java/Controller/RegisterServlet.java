package Controller;

import java.io.IOException;

import dao.UserDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserDAO dao = new UserDAO();
        boolean success = dao.registerUser(name, email, password);

        if (success) {
            response.sendRedirect("jsp/login.jsp?msg=registered");
        } else {
            response.sendRedirect("jsp/register.jsp?error=failed");
        }
    }
}
