package Controller;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import dao.IncidentDAO;
import model.Incident;
import model.User;

@WebServlet("/ReportIncidentServlet")
public class ReportIncidentServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // 🔹 Show form
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
            return;
        }

        RequestDispatcher rd = request.getRequestDispatcher("/jsp/reportIncident.jsp");
        rd.forward(request, response);
    }

    // 🔥 SAVE DATA
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
            return;
        }

        // Get form data
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String type = request.getParameter("type");
        String priority = request.getParameter("priority");

        // Create object
        Incident incident = new Incident();
        incident.setTitle(title);
        incident.setDescription(description);
        incident.setType(type);
        incident.setPriority(priority);
        incident.setStatus("OPEN"); // default status
        incident.setUserId(user.getUserId()); // 🔥 VERY IMPORTANT

        // Save to DB
        IncidentDAO dao = new IncidentDAO();
        dao.addIncident(incident);

        // Redirect back
        response.sendRedirect(request.getContextPath() + "/jsp/userDashboard.jsp");
    }
}