package Controller;

import dao.IncidentDAO;
import model.Incident;
import model.User;
import util.EmailUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/AddIncidentServlet")
public class AddIncidentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {

            String title = request.getParameter("title");
            String description = request.getParameter("description");
            String type = request.getParameter("type");
            String priority = request.getParameter("priority");

            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");

            if (user == null) {
                response.sendRedirect("jsp/login.jsp");
                return;
            }

            Incident incident = new Incident();

            incident.setTitle(title);
            incident.setDescription(description);
            incident.setType(type);
            incident.setPriority(priority);
            incident.setStatus("Pending");
            incident.setUserId(user.getUserId());

            IncidentDAO dao = new IncidentDAO();

            boolean status = dao.addIncident(incident);

            if (status) {

                // Send Email Notification
                String email = user.getEmail();

                EmailUtil.sendEmail(
                    email,
                    "Cyber Incident Report Submitted",
                    "Dear User,\n\n" +
                    "Your cyber incident has been successfully submitted.\n\n" +
                    "Incident Title: " + title + "\n" +
                    "Type: " + type + "\n" +
                    "Priority: " + priority + "\n" +
                    "Current Status: Pending\n\n" +
                    "Our security team will review it shortly.\n\n" +
                    "Regards,\nCyber Incident System"
                );

                response.sendRedirect("ViewIncidentServlet");

            } else {
                response.getWriter().println("Incident not saved");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}