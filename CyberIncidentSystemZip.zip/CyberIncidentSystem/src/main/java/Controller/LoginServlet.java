package Controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import dao.UserDAO;
import model.User;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        UserDAO userDAO = new UserDAO();
        User user = userDAO.login(email, password);

        if (user != null) {

            HttpSession session = request.getSession();

            session.setAttribute("user", user);
            session.setAttribute("userId", user.getUserId());
            session.setAttribute("role", user.getRole()); // ✅ IMPORTANT

            if ("ADMIN".equals(user.getRole())) {
                response.sendRedirect(request.getContextPath() + "/jsp/dashboard.jsp");
            } else {
                response.sendRedirect(request.getContextPath() + "/jsp/userDashboard.jsp");
            }

        } else {
            response.sendRedirect(request.getContextPath() + "/jsp/login.jsp?error=Invalid Email or Password");
        }
    }
}