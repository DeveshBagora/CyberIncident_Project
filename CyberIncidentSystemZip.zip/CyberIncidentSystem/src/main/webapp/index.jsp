<!DOCTYPE html>
<html>
<head>
    <title>Cyber Incident Reporting System</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #020617, #0f172a, #1e293b);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        overflow: hidden;
    }

    .container {
        text-align: center;
        max-width: 900px;
        padding: 50px;
        background: rgba(255,255,255,0.05);
        backdrop-filter: blur(16px);
        border-radius: 24px;
        box-shadow: 0 12px 40px rgba(0,0,0,0.45);
    }

    .icon {
        font-size: 80px;
        margin-bottom: 20px;
    }

    h1 {
        font-size: 42px;
        color: #60a5fa;
        margin-bottom: 18px;
    }

    .subtitle {
        font-size: 18px;
        color: #cbd5e1;
        line-height: 1.7;
        margin-bottom: 35px;
    }

    .features {
        display: flex;
        justify-content: center;
        gap: 25px;
        margin-bottom: 35px;
        flex-wrap: wrap;
    }

    .feature-box {
        background: rgba(255,255,255,0.05);
        padding: 18px 22px;
        border-radius: 14px;
        min-width: 180px;
        transition: 0.3s;
    }

    .feature-box:hover {
        transform: translateY(-6px);
        box-shadow: 0 8px 20px rgba(37,99,235,0.25);
    }

    .feature-box h3 {
        margin-bottom: 8px;
        color: #93c5fd;
    }

    .feature-box p {
        font-size: 14px;
        color: #cbd5e1;
    }

    .buttons {
        margin-top: 20px;
    }

    .btn {
        display: inline-block;
        padding: 14px 28px;
        margin: 10px;
        text-decoration: none;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        transition: 0.3s;
    }

    .register {
        background: #2563eb;
        color: white;
    }

    .register:hover {
        background: #1d4ed8;
        transform: translateY(-3px);
    }

    .login {
        background: transparent;
        border: 2px solid #60a5fa;
        color: #60a5fa;
    }

    .login:hover {
        background: #60a5fa;
        color: white;
        transform: translateY(-3px);
    }

    .footer {
        margin-top: 35px;
        font-size: 14px;
        color: #94a3b8;
    }

    @media (max-width: 768px) {
        h1 {
            font-size: 30px;
        }

        .subtitle {
            font-size: 16px;
        }

        .container {
            margin: 20px;
            padding: 30px;
        }
    }
</style>
</head>

<body>

<div class="container">

    <div class="icon">🛡️</div>

    <h1>Cyber Incident Reporting System</h1>

    <p class="subtitle">
        A secure platform for reporting, monitoring, and managing cyber incidents efficiently.
        Protect digital assets through fast reporting and streamlined investigation workflows.
    </p>

    <div class="features">

        <div class="feature-box">
            <h3>⚠ Incident Reporting</h3>
            <p>Report cyber threats quickly and securely.</p>
        </div>

        <div class="feature-box">
            <h3>🔍 Investigation</h3>
            <p>Track and analyze reported incidents.</p>
        </div>

        <div class="feature-box">
            <h3>🔐 Secure Access</h3>
            <p>Role-based protected system access.</p>
        </div>

    </div>

    <div class="buttons">
        <a href="jsp/register.jsp" class="btn register">Register</a>
        <a href="jsp/login.jsp" class="btn login">Login</a>
    </div>

    <div class="footer">
        MCA Major Project • Cyber Security Domain
    </div>

</div>

</body>
</html>