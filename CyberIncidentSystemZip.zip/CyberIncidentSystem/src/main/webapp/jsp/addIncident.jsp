<%@ include file="userSidebar.jsp" %>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Report Cyber Incident</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
    }

    .container {
        width: 100%;
        max-width: 500px;
        background: #ffffff;
        color: #333;
        padding: 35px;
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }

    .container h2 {
        text-align: center;
        margin-bottom: 25px;
        color: #0f172a;
        font-size: 28px;
    }

    .form-group {
        margin-bottom: 18px;
    }

    label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #334155;
    }

    input[type="text"],
    select,
    textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        font-size: 15px;
        transition: 0.3s;
    }

    input[type="text"]:focus,
    select:focus,
    textarea:focus {
        border-color: #2563eb;
        outline: none;
        box-shadow: 0 0 8px rgba(37, 99, 235, 0.3);
    }

    textarea {
        resize: none;
        height: 120px;
    }

    .btn {
        width: 100%;
        padding: 14px;
        background: #2563eb;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }

    .btn:hover {
        background: #1d4ed8;
        transform: translateY(-2px);
    }

    .icon {
        text-align: center;
        font-size: 45px;
        margin-bottom: 15px;
    }

</style>
</head>
<body>

<div class="container">
    <div class="icon">🛡️</div>
    <h2>Report Cyber Incident</h2>

    <form action="<%= request.getContextPath() %>/AddIncidentServlet" method="post">

        <div class="form-group">
            <label>Incident Title</label>
            <input type="text" name="title" placeholder="Enter incident title" required>
        </div>

        <div class="form-group">
            <label>Incident Type</label>
            <select name="incidentType">
                <option>Phishing</option>
                <option>Malware</option>
                <option>Data Breach</option>
                <option>Unauthorized Access</option>
                <option>Ransomware</option>
            </select>
        </div>

        <div class="form-group">
            <label>Description</label>
            <textarea name="description" placeholder="Describe the incident in detail..."></textarea>
        </div>

        <button type="submit" class="btn">Report Incident</button>

    </form>
</div>

</body>
</html>