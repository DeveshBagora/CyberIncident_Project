<%@ include file="userSidebar.jsp" %>
<%@ page import="java.util.*, model.Incident" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
    List<Incident> incidents = (List<Incident>) request.getAttribute("incidents");
    if(incidents == null){
        incidents = new ArrayList<>();
    }
%>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>My Incidents</title>

<style>
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #000814, #001d3d);
    color: white;
}

.container {
    padding-top:20px;
    width: 90%;
    margin: 50px auto;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

h1 {
    font-size: 48px;
    margin-bottom: 30px;
}

.total-box {
    background: rgba(255,255,255,0.08);
    padding: 20px 30px;
    border-radius: 18px;
    font-size: 20px;
    font-weight: bold;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: rgba(255,255,255,0.03);
    border-radius: 18px;
    overflow: hidden;
}

th {
    background: rgba(255,255,255,0.08);
    padding: 20px;
    text-align: center;
    font-size: 22px;
    font-weight: bold;
}

td {
    padding: 22px;
    text-align: center;
    font-size: 18px;
    border-bottom: 1px solid rgba(255,255,255,0.08);
}

tr:hover {
    background: rgba(255,255,255,0.05);
}

.status {
    color: #ffd60a;
    font-weight: bold;
}

.high {
    color: #ff4d4d;
    font-weight: bold;
}

.medium {
    color: #ff8c42;
    font-weight: bold;
}

.low {
    color: #4caf50;
    font-weight: bold;
}

.back-btn {
    display: inline-block;
    margin-top: 30px;
    background: #2563eb;
    color: white;
    padding: 16px 30px;
    text-decoration: none;
    border-radius: 12px;
    font-size: 18px;
    font-weight: bold;
    transition: 0.3s;
}

.back-btn:hover {
    background: #1d4ed8;
    transform: translateY(-2px);
}
</style>
</head>

<body>

<div class="container">

    <div class="header">
        <h1>My Incidents</h1>
        <div class="total-box">Total: <%= incidents.size() %></div>
    </div>

    <table>
        <tr>
            <th>Title</th>
            <th>Status</th>
            <th>Priority</th>
        </tr>

        <%
            for(Incident i : incidents){
        %>
        <tr>
            <td><%= i.getTitle() %></td>
            <td class="status"><%= i.getStatus() %></td>

            <td class="
                <%= i.getPriority().equalsIgnoreCase("HIGH") ? "high" :
                    i.getPriority().equalsIgnoreCase("MEDIUM") ? "medium" : "low" %>
            ">
                <%= i.getPriority() %>
            </td>
        </tr>
        <%
            }
        %>
    </table>

    <a class="back-btn" href="<%= request.getContextPath() %>/jsp/userDashboard.jsp">
        ← Back to Dashboard
    </a>

</div>

</body>
</html>