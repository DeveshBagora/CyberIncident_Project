<!DOCTYPE html>
<html>
<head>
<title>Report Incident</title>

<style>
body { background:#0f172a; color:white; font-family:Arial; }
form { width:300px; margin:50px auto; }
input, select, textarea {
    width:100%; margin:10px 0; padding:10px;
}
button {
    background:#22c55e; padding:10px; border:none;
}
</style>
</head>

<body>

<form action="<%= request.getContextPath() %>/AddIncidentServlet" method="post">
<h2>Report Incident</h2>

<input type="text" name="title" placeholder="Title" required>
<textarea name="description" placeholder="Description"></textarea>

<select name="type" required>
    <option value="Phishing">Phishing</option>
    <option value="Malware">Malware</option>
    <option value="Data Breach">Data Breach</option>
</select>

<select name="priority">
<option>Low</option>
<option>Medium</option>
<option>High</option>
</select>

<button type="submit">Submit</button>

</form>

</body>
</html>