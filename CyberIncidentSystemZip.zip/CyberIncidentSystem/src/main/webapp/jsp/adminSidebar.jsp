<div class="sidebar">
    <h2>CyberSys</h2>

    <a href="<%=request.getContextPath()%>/DashboardServlet">Dashboard</a>

    <a href="<%=request.getContextPath()%>/AdminUsersServlet">Manage Users</a>

    <a href="<%=request.getContextPath()%>/AdminViewIncidentsServlet">View Incidents</a>

    <a href="<%=request.getContextPath()%>/LogoutServlet">Logout</a>
</div>

<style>
.sidebar{
    width:250px;
    height:100vh;
    background:#020617;
    position:fixed;
    left:0;
    top:0;
    padding:30px 20px;
}

.sidebar h2{
    color:#22c55e;
    margin-bottom:40px;
}

.sidebar a{
    display:block;
    color:white;
    text-decoration:none;
    padding:15px 10px;
    margin-bottom:10px;
    border-radius:8px;
}

.sidebar a:hover{
    background:#1e293b;
}
</style>