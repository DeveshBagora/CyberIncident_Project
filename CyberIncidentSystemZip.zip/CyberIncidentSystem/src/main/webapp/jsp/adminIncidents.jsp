<%@ include file="adminSidebar.jsp" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, model.Incident" %>
<%
    List<Incident> list = (List<Incident>) request.getAttribute("incidents");
%>

<!DOCTYPE html>
<html>
<head>
<title>Admin - Manage Incidents</title>

<style>
body {
    background: #0f172a;
    color: white;
    font-family: Arial;
}

.container {
    margin-left:270px;
    padding: 30px;
}

h2 {
    font-size: 32px;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background: #1e293b;
}

th, td {
    padding: 14px;
    border-bottom: 1px solid #334155;
    text-align: center;
}

th {
    background: #334155;
}

tr:hover {
    background: #273549;
}

select {
    padding: 6px;
    border-radius: 6px;
}

.update-btn {
    padding: 8px 14px;
    background: #2563eb;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.update-btn:hover {
    background: #1d4ed8;
}

.delete-btn {
    color: red;
    text-decoration: none;
}
</style>

</head>
<body>

<div class="container">

<h2>Manage Incidents</h2>

<table>
<tr>
    <th>ID</th>
    <th>Title</th>
    <th>Current Status</th>
    <th>Priority</th>
    <th>Update Status</th>
    <th>Delete</th>
</tr>

<% if(list != null && !list.isEmpty()) { %>

    <% for(Incident i : list){ %>
    <tr>
        <td><%= i.getIncidentId() %></td>
        <td><%= i.getTitle() %></td>
        <td><%= i.getStatus() %></td>
        <td><%= i.getPriority() %></td>

        <td>
            <form action="<%=request.getContextPath()%>/UpdateIncidentStatusServlet" method="post">

                <input type="hidden" name="incidentId" value="<%= i.getIncidentId() %>">
                <input type="hidden" name="userId" value="<%= i.getUserId() %>">

                <select name="status">
                    <option>Pending</option>
                    <option>Investigating</option>
                    <option>Resolved</option>
                    <option>Rejected</option>
                </select>

                <input class="update-btn" type="submit" value="Update">

            </form>
        </td>

        <td>
            <a class="delete-btn"
               href="<%=request.getContextPath()%>/DeleteIncidentServlet?id=<%=i.getIncidentId()%>">
               Delete
            </a>
        </td>
 
    </tr>
    <% } %>

<% } else { %>

<tr>
    <td colspan="6">No Data Found</td>
</tr>

<% } %>

</table>

</div>

</body>
</html>