<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
    }

    .container {
        width: 100%;
        max-width: 450px;
        background: rgba(255, 255, 255, 0.08);
        backdrop-filter: blur(15px);
        border-radius: 18px;
        padding: 35px;
        box-shadow: 0 10px 35px rgba(0,0,0,0.4);
    }

    .logo {
        text-align: center;
        font-size: 50px;
        margin-bottom: 10px;
    }

    h2 {
        text-align: center;
        margin-bottom: 25px;
        color: #60a5fa;
        font-size: 28px;
    }

    .subtitle {
        text-align: center;
        color: #cbd5e1;
        margin-bottom: 30px;
        font-size: 14px;
    }

    .form-group {
        margin-bottom: 18px;
    }

    label {
        display: block;
        margin-bottom: 8px;
        color: #e2e8f0;
        font-weight: 500;
    }

    input, select {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 10px;
        background: #f8fafc;
        font-size: 15px;
        transition: 0.3s;
    }

    input:focus, select:focus {
        outline: none;
        box-shadow: 0 0 10px rgba(96,165,250,0.5);
    }

    .btn {
        width: 100%;
        padding: 14px;
        background: #2563eb;
        color: white;
        border: none;
        border-radius: 10px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
        margin-top: 10px;
    }

    .btn:hover {
        background: #1d4ed8;
        transform: translateY(-2px);
    }

    .login-link {
        text-align: center;
        margin-top: 20px;
    }

    .login-link a {
        color: #60a5fa;
        text-decoration: none;
        font-weight: 500;
    }

    .login-link a:hover {
        text-decoration: underline;
    }

    @media (max-width: 500px) {
        .container {
            margin: 20px;
            padding: 25px;
        }

        h2 {
            font-size: 24px;
        }
    }
</style>
</head>

<body>

<div class="container">

    <div class="logo">🛡️</div>

    <h2>User Registration</h2>
    <div class="subtitle">Cyber Incident Reporting System</div>

    <form action="<%= request.getContextPath() %>/register" method="post">

        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="name" placeholder="Enter your full name" required>
        </div>

        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="Enter your email" required>
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Create password" required>
        </div>

        <div class="form-group">
            <label>Select Role</label>
            <select name="role">
                <option value="USER">USER</option>
                <option value="INVESTIGATOR">INVESTIGATOR</option>
            </select>
        </div>

        <button type="submit" class="btn">Register</button>

    </form>

    <div class="login-link">
        Already have an account?
        <a href="<%=request.getContextPath()%>/jsp/login.jsp">Login Here</a>
    </div>

</div>

</body>
</html>