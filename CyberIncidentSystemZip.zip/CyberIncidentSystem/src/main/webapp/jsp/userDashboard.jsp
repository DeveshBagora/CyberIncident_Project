<%@ include file="userSidebar.jsp" %>
<%@ page contentType="text/html;charset=UTF-8" %>

<%
    if (session == null || session.getAttribute("user") == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<%
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);
%>

<%
String role = (String) session.getAttribute("role");
if(role == null || !role.equals("USER")){
    response.sendRedirect(request.getContextPath() + "/jsp/login.jsp");
    return;
}
%>

<!DOCTYPE html>
<html>
<head>
<title>User Dashboard</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
    }

    .dashboard {
        width: 90%;
        max-width: 900px;
        background: rgba(255,255,255,0.08);
        backdrop-filter: blur(14px);
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 12px 35px rgba(0,0,0,0.45);
    }

    .header {
        text-align: center;
        margin-bottom: 35px;
    }

    .header h2 {
        font-size: 32px;
        color: #60a5fa;
    }

    .header p {
        color: #cbd5e1;
        margin-top: 8px;
    }

    .cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
    }

    .card {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 16px;
        padding: 25px;
        text-align: center;
        transition: 0.3s;
    }

    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 8px 20px rgba(37,99,235,0.3);
    }

    .card-icon {
        font-size: 45px;
        margin-bottom: 15px;
    }

    .card h3 {
        margin-bottom: 10px;
        color: #e2e8f0;
    }

    .card p {
        color: #94a3b8;
        font-size: 14px;
        margin-bottom: 20px;
    }

    .btn {
        display: inline-block;
        padding: 12px 18px;
        background: #2563eb;
        color: white;
        text-decoration: none;
        border-radius: 10px;
        font-weight: 600;
        transition: 0.3s;
    }

    .btn:hover {
        background: #1d4ed8;
    }

    .logout {
        background: #dc2626;
    }

    .logout:hover {
        background: #b91c1c;
    }

    @media (max-width: 768px) {
        .dashboard {
            padding: 25px;
        }

        .header h2 {
            font-size: 26px;
        }
    }
</style>
</head>

<body>

<div class="dashboard">

    <div class="header">
        <h2>🛡️ Welcome User</h2>
        <p>Cyber Incident Reporting Dashboard</p>
    </div>

    <div class="cards">

        <div class="card">
            <div class="card-icon">⚠️</div>
            <h3>Report Incident</h3>
            <p>Submit a new cyber incident report securely.</p>
            <a class="btn" href="<%= request.getContextPath() %>/ReportIncidentServlet">
                Report Now
            </a>
        </div>

        <div class="card">
            <div class="card-icon">📂</div>
            <h3>My Incidents</h3>
            <p>Track and review all your reported incidents.</p>
            <a class="btn" href="<%= request.getContextPath() %>/ViewIncidentServlet">
                View Reports
            </a>
        </div>

        <div class="card">
            <div class="card-icon">🚪</div>
            <h3>Logout</h3>
            <p>Securely exit your dashboard session.</p>
            <a class="btn logout" href="<%= request.getContextPath() %>/LogoutServlet">
                Logout
            </a>
        </div>

    </div>

</div>

</body>
</html>