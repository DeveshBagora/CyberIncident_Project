<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<style>
body { background:#020617; color:white; display:flex; justify-content:center; align-items:center; height:100vh; }
form { background:#1e293b; padding:30px; border-radius:10px; }
input { display:block; margin:10px 0; padding:10px; width:250px; }
button { background:#22c55e; padding:10px; border:none; width:100%; }
</style>
</head>

<body>

<form action="<%=request.getContextPath()%>/LoginServlet"method="post">
<h2>Login</h2>

<input type="email" name="email" placeholder="Email">
<input type="password" name="password" placeholder="Password">

<button type="submit">Login</button>

</form>

</body>
</html>