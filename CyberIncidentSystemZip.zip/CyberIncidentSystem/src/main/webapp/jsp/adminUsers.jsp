<%@ include file="adminSidebar.jsp" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="java.util.*, model.User" %>

<%
    List<User> users = (List<User>) request.getAttribute("users");
%>

<!DOCTYPE html>
<html>
<head>
<title>Manage Users</title>

<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Segoe UI', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        min-height: 100vh;
        color: white;
        padding: 30px;
    }

    .container {
        max-width: 1200px;
        margin: auto;
        background: rgba(255,255,255,0.05);
        backdrop-filter: blur(12px);
        border-radius: 18px;
        padding: 30px;
        box-shadow: 0 10px 35px rgba(0,0,0,0.4);
    }

    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }

    .header h2 {
        font-size: 30px;
        color: #60a5fa;
    }

    .header p {
        color: #cbd5e1;
        font-size: 14px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        overflow: hidden;
        border-radius: 12px;
        background: #1e293b;
    }

    th {
        background: #2563eb;
        color: white;
        padding: 16px;
        text-align: left;
        font-size: 15px;
        letter-spacing: 0.5px;
    }

    td {
        padding: 15px;
        border-bottom: 1px solid #334155;
        color: #e2e8f0;
    }

    tr:hover {
        background: rgba(37, 99, 235, 0.15);
        transition: 0.3s;
    }

    .btn {
        padding: 8px 14px;
        border-radius: 8px;
        text-decoration: none;
        font-size: 14px;
        font-weight: 600;
        transition: 0.3s;
    }

    .delete {
        background: #dc2626;
        color: white;
    }

    .delete:hover {
        background: #b91c1c;
        transform: translateY(-2px);
    }

    .user-count {
        margin-bottom: 20px;
        color: #94a3b8;
        font-size: 15px;
    }

    .empty {
        text-align: center;
        padding: 30px;
        color: #94a3b8;
        font-size: 18px;
    }

    @media (max-width: 768px) {
        table {
            font-size: 14px;
        }

        th, td {
            padding: 10px;
        }

        .header h2 {
            font-size: 24px;
        }
    }
</style>
</head>

<body>

<div class="container">

    <div class="header">
        <div>
            <h2>👥 Manage Users</h2>
            <p>Admin Control Panel</p>
        </div>
    </div>

    <div class="user-count">
        Total Users: <strong><%= users != null ? users.size() : 0 %></strong>
    </div>

    <table>
        <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Email Address</th>
            <th>Role</th>
            <th>Action</th>
        </tr>

        <% if(users != null && !users.isEmpty()) { 
            for(User u : users){ %>
        <tr>
            <td><%= u.getUserId() %></td>
            <td><%= u.getName() %></td>
            <td><%= u.getEmail() %></td>
            <td><%= u.getRole() %></td>
            <td>
                <a class="btn delete"
                   href="DeleteUserServlet?id=<%=u.getUserId()%>"
                   onclick="return confirm('Are you sure you want to delete this user?');">
                   Delete
                </a>
            </td>
        </tr>
        <% } 
        } else { %>
        <tr>
            <td colspan="5" class="empty">No users found</td>
        </tr>
        <% } %>

    </table>

</div>

</body>
</html>