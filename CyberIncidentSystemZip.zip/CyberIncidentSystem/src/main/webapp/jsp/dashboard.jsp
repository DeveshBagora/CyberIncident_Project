<%@ include file="adminSidebar.jsp" %>
<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="model.User" %>
<%
    // Session check
    User user = (User) session.getAttribute("user");

    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    // Prevent back after logout
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);
%>

<!DOCTYPE html>
<html>
<head>
    <title>Cyber Incident System - Dashboard</title>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', sans-serif;
        }

        body {
            display: flex;
            background-color: #0f172a;
            color: #e2e8f0;
        }

        /* Sidebar */
        .sidebar {
            width: 240px;
            height: 100vh;
            background: #020617;
            padding: 20px;
        }

        .sidebar h2 {
            color: #22c55e;
            margin-bottom: 30px;
        }

        .sidebar a {
            display: block;
            color: #cbd5e1;
            text-decoration: none;
            margin: 10px 0;
            padding: 10px;
            border-radius: 8px;
            transition: 0.3s;
        }

        .sidebar a:hover {
            background: #1e293b;
            color: #22c55e;
        }

        /* Main */
        .main {
            flex: 1;
            padding: 20px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .logout-btn {
            background: #ef4444;
            padding: 8px 15px;
            color: white;
            text-decoration: none;
            border-radius: 6px;
        }

        .logout-btn:hover {
            background: #dc2626;
        }

        /* Cards */
        .cards {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }

        .card {
            flex: 1;
            background: #1e293b;
            padding: 20px;
            border-radius: 12px;
        }

        .card h3 {
            margin-bottom: 10px;
        }

        .card p {
            font-size: 22px;
            color: #22c55e;
        }

        /* Charts */
        .charts {
            margin-top: 40px;
            display: flex;
            gap: 30px;
        }

        canvas {
            background: #1e293b;
            padding: 20px;
            border-radius: 10px;
            width: 100% !important;
            max-width: 500px;
        }

        .section {
            margin-top: 30px;
        }

        a.link-btn {
            display: inline-block;
            padding: 10px 15px;
            background: #1e293b;
            color: #e2e8f0;
            border-radius: 6px;
            text-decoration: none;
            margin-right: 10px;
        }

        a.link-btn:hover {
            background: #22c55e;
            color: black;
        }
    </style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>🛡 CyberSys</h2>

    <a href="<%=request.getContextPath()%>/DashboardServlet">Dashboard</a>

    <% if ("ADMIN".equalsIgnoreCase(user.getRole())) { %>
        <a href="<%=request.getContextPath()%>/AdminUsersServlet?action=list">Manage Users</a>
        <a href="<%=request.getContextPath()%>/AdminViewIncidentsServlet?action=list">View Incidents</a>
    <% } else if ("INVESTIGATOR".equalsIgnoreCase(user.getRole())) { %>
        <a href="#">Assigned Incidents</a>
    <% } else { %>
        <a href="<%=request.getContextPath()%>/jsp/reportIncident.jsp">Report Incident</a>
        <a href="<%=request.getContextPath()%>/jsp/viewincidents.jsp">My Incidents</a>
    <% } %>
</div>

<!-- Main -->
<div class="main">

    <!-- Topbar -->
    <div class="topbar">
        <h2>Dashboard</h2>
        <a class="logout-btn" href="<%= request.getContextPath() %>/LogoutServlet">Logout</a>
    </div>

    <!-- Welcome -->
    <h2>Welcome, <%= user.getName() %> 👋</h2>
    <p><%= user.getEmail() %> | Role: <%= user.getRole() %></p>

    <!-- Cards (Dynamic Data) -->
    <div class="cards">
        <div class="card">
            <h3>Total Users</h3>
            <p>${totalUsers}</p>
        </div>

        <div class="card">
            <h3>Total Incidents</h3>
            <p>${totalIncidents}</p>
        </div>

        <div class="card">
            <h3>Resolved Cases</h3>
            <p>${resolved}</p>
        </div>
    </div>

    <!-- Charts -->
    <div class="charts">
        <canvas id="incidentChart"></canvas>
        <canvas id="severityChart"></canvas>
    </div>

    <!-- Role Actions -->
    <div class="section">

        <% if ("ADMIN".equalsIgnoreCase(user.getRole())) { %>
            <h3>Admin Actions</h3>
            <a class="link-btn" href="<%=request.getContextPath()%>/AdminUsersServlet?action=list">Manage Users</a>
            <a class="link-btn" href="<%=request.getContextPath()%>/AdminViewIncidentsServlet?action=list">View Incidents</a>

        <% } else if ("INVESTIGATOR".equalsIgnoreCase(user.getRole())) { %>
            <h3>Investigator Panel</h3>
            <a class="link-btn" href="#">Assigned Incidents</a>

        <% } else { %>
            <h3>User Panel</h3>
            <a class="link-btn" href="<%=request.getContextPath()%>/jsp/reportIncident.jsp">Report Incident</a>
            <a class="link-btn" href="<%=request.getContextPath()%>/jsp/viewincidents.jsp">My Incidents</a>
        <% } %>

    </div>

</div>

<!-- Charts Script -->
<script>
    const incidentData = {
        labels: ["Pending", "Resolved", "In Progress"],
        datasets: [{
            label: "Incidents",
            data: [${pending}, ${resolved}, ${inProgress}],
            backgroundColor: ["#facc15", "#22c55e", "#3b82f6"]
        }]
    };

    const severityData = {
        labels: ["Low", "Medium", "High"],
        datasets: [{
            label: "Severity",
            data: [${low}, ${medium}, ${high}],
            backgroundColor: ["#22c55e", "#f97316", "#ef4444"]
        }]
    };

    new Chart(document.getElementById("incidentChart"), {
        type: "bar",
        data: incidentData,
        options: {
            plugins: { legend: { labels: { color: "white" } } },
            scales: {
                x: { ticks: { color: "white" } },
                y: { ticks: { color: "white" } }
            }
        }
    });

    new Chart(document.getElementById("severityChart"), {
        type: "pie",
        data: severityData,
        options: {
            plugins: { legend: { labels: { color: "white" } } }
        }
    });
</script>

</body>
</html>